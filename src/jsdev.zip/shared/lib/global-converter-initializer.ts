export abstract class BaseConverterController<T> {
  protected elements: T | null = null;
  constructor(converterName?: string) {
    // 🔕 Global auto-init disabled
  }
}