export interface ConverterConfig {
  name: string;
  requiredElements: string[];
  controllerClass: any;
  initFunction?: () => void;
}

class UniversalConverterManager {
  private static instance: UniversalConverterManager;

  static getInstance(): UniversalConverterManager {
    if (!UniversalConverterManager.instance) {
      UniversalConverterManager.instance = new UniversalConverterManager();
    }
    return UniversalConverterManager.instance;
  }

  registerConverter(config: ConverterConfig): void {
    // 🔕 Global converter system disabled
  }
}

export const converterManager = UniversalConverterManager.getInstance();